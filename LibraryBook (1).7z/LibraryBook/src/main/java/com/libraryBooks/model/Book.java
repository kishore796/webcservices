package com.libraryBooks.model;


import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "BOOK")
public class Book implements Serializable{
	
	@Id
	@Column(name = "book_id")
	private String bookId;
	
	@Column(name = "book_name")
	private String bookName;
	
	
	private String author;
	
	@Column(name = "available_copies")
	private Integer availableCopies;
	
	@Column(name = "total_copies")
	private Integer totalCopies;
	
	@Transient
	private boolean status;
	
	public Book() {
		// TODO Auto-generated constructor stub
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Integer getAvailableCopies() {
		return availableCopies;
	}

	public void setAvailableCopies(Integer availableCopies) {
		this.availableCopies = availableCopies;
	}

	public Integer getTotalCopies() {
		return totalCopies;
	}

	public void setTotalCopies(Integer totalCopies) {
		this.totalCopies = totalCopies;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", author=" + author + ", availableCopies="
				+ availableCopies + ", totalCopies=" + totalCopies + ", status=" + status + "]";
	}
	


}
