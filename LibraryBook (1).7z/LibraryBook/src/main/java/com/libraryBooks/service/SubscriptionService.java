package com.libraryBooks.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.libraryBooks.dao.SubscriptionDao;
import com.libraryBooks.model.Book;
import com.libraryBooks.model.Subscription;

@Service
public class SubscriptionService {
	
	@Autowired
	private SubscriptionDao subs;
	@Autowired
	private BookService book;
	
	
	public Subscription getSubsByName(String subscriberName) {
		Optional<Subscription> data = subs.findById(subscriberName);
		if(data.isPresent())
		 return data.get();
		return null;
	}
	
	
	public List<Subscription> getAllSubs() {
		 List<Subscription> subsList =  new ArrayList<>();
		 List<Subscription> subsWithBook =  new ArrayList<>();
		subsList = subs.findAll();
		for(Subscription s :subsList) {
			Book bookData = book.getBookByID(s.getBookId());
			s.setBook(bookData);
			subsWithBook.add(s);
		}
		return subsWithBook;
	}


	public List<Subscription> createSubs(Subscription data) {
		Book bookItem = book.getBookByID(data.getBookId());
		data.setNotify("No");
		Subscription subData = getSubsByName(data.getSubscriberName());
		
		if(subData ==  null) {
			if(bookItem != null && bookItem.getAvailableCopies() > 0) {
				book.updateAvailability(bookItem.getBookId(), -1);
			}
			else if(bookItem != null && bookItem.getAvailableCopies() == 0) {
				data.setNotify("yes");
			}
			
		}else {
			if(bookItem != null && bookItem.getAvailableCopies() > 0) {
				book.updateAvailability(bookItem.getBookId(), 1);
			}
		}
		
		subs.save(data);
		return subs.findAll();
	}

	
	
}
