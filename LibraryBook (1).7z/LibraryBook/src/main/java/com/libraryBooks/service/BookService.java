package com.libraryBooks.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.libraryBooks.dao.BookDao;
import com.libraryBooks.model.Book;

@Service
public class BookService {
	
	@Autowired
	private BookDao book;
	
	public List<Book> getBooks(){
		return book.findAll();
	}

	public Book getBookByID(String bookId) {
		
		Optional<Book> data = book.findById(bookId);
		return data.isPresent() ? data.get() : null;
		//return book.findById(bookId);
	}

	public Book updateAvailability(String bookId, int availableCopies) {
		Optional<Book> updateBook = null;
		Book data = getBookByID(bookId);
		if (data != null) {
			data.setAvailableCopies(data.getAvailableCopies() + availableCopies);
			book.save(data);
		}
		updateBook = book.findById(bookId);
		return updateBook.isPresent() ? updateBook.get() : null;
	}

}
