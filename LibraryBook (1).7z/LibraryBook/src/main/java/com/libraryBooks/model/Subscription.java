package com.libraryBooks.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;


@Entity
@Table(name = "SUBSCRIPTION")
public class Subscription implements Serializable{
	
	
	@Id
	@Column(name = "subscriber_name")
	private String subscriberName;
	
	@Column(name = "date_subscribed")
	private Date dateSubscribed;
	
	@Column(name = "date_returned")
	private Date dateReturned;
	
	@Column(name = "book_id")
	private String bookId;
	
	@Transient
	private Book book;
	
	@Transient
	private String notify;
	
	public Subscription() {
		// TODO Auto-generated constructor stub
	}


	public String getSubscriberName() {
		return subscriberName;
	}


	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}


	public Date getDateSubscribed() {
		return dateSubscribed;
	}


	public void setDateSubscribed(Date dateSubscribed) {
		this.dateSubscribed = dateSubscribed;
	}


	public Date getDateReturned() {
		return dateReturned;
	}


	public void setDateReturned(Date dateReturned) {
		this.dateReturned = dateReturned;
	}


	public String getBookId() {
		return bookId;
	}


	public void setBookId(String bookId) {
		this.bookId = bookId;
	}


	public Book getBook() {
		return book;
	}


	public void setBook(Book book) {
		this.book = book;
	}


	public String getNotify() {
		return notify;
	}


	public void setNotify(String notify) {
		this.notify = notify;
	}


	@Override
	public String toString() {
		return "Subscription [subscriberName=" + subscriberName + ", dateSubscribed=" + dateSubscribed
				+ ", dateReturned=" + dateReturned + ", bookId=" + bookId + ", book=" + book + ", notify=" + notify
				+ "]";
	}

	
	

	
	

}
