package com.libraryBooksServices.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.libraryBooksServices.dao.SubscriptionDao;
import com.libraryBooksServices.model.Book;
import com.libraryBooksServices.model.Subscription;
import org.springframework.core.ParameterizedTypeReference;
@Service
public class SubscriptionService {
	
	@Autowired
	private SubscriptionDao subs;
	
	
	
	@Autowired
    RestTemplate restTemplate;
	
	private  String url ="http://BookServices/books/";
	
	
	public Subscription getSubsByName(String subscriberName) {
		Optional<Subscription> data = subs.findById(subscriberName);
		if(data.isPresent())
		 return data.get();
		return null;
	}
	
	
	public List<Subscription> getAllSubs() {
		 List<Subscription> subsList =  new ArrayList<>();
		 List<Subscription> subsWithBook =  new ArrayList<>();
		 
	        
		subsList = subs.findAll();
		for(Subscription s :subsList) {
			//Book bookData = book.getBookByID(s.getBookId());
			 //url +=""+s.getBookId();
			//Book data = this.restTemplate.getForObject(url, Book.class);
			String bookId = s.getBookId();
			Book data = restTemplate.exchange("http://BookServices/books/{bookId}",
					HttpMethod.GET, null, new ParameterizedTypeReference<Book>() {}, bookId).getBody();
			//Book data = restTemplate.getForObject("http://BookServices/books/{bookId}", bookId,  Book.class);
			s.setBook(data);
			subsWithBook.add(s);
		}
		return subsWithBook;
	}


	public List<Subscription> createSubs(Subscription data) {

		Book bookItem = this.restTemplate.getForObject(url+data.getBookId(), Book.class);
		Book bookData = null;
		
		data.setNotify("No");
		Subscription subData = getSubsByName(data.getSubscriberName());
		
		if(subData ==  null) {
			if(bookItem != null && bookItem.getAvailableCopies() > 0) {
				
			 bookData =	this.restTemplate.getForObject(url+"/UpdateAvailability/"+bookItem.getBookId()+"/"+-1, Book.class);
				
			}
			else if(bookItem != null && bookItem.getAvailableCopies() == 0) {
				data.setNotify("yes");
			}
			
		}else {
			if(bookItem != null && bookItem.getAvailableCopies() > 0) {
				 bookData = this.restTemplate.getForObject(url+"/UpdateAvailability/"+bookItem.getBookId()+"/"+1, Book.class);
						
			}
		}
		
		subs.save(data);
		return subs.findAll();
	}

	
	
}
