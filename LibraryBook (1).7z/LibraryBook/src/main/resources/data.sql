INSERT INTO USER (id, subscriber_name, password, email) VALUES ('John', 'John Miller', 'abc', 'abc@gmail.com');
INSERT INTO USER (id, subscriber_name, password, email) VALUES ('Mark', 'Mark Waughn','abc', 'xyz@email.com');
INSERT INTO USER (id, subscriber_name, password, email) VALUES ('Peter', 'Peter America','abc', 'cap@marvel.com');
  
INSERT INTO BOOK (book_id,  book_name, author,available_copies, total_copies) VALUES ('B1212', 'You Can Win', 'Shiv Khera',0, 2);
INSERT INTO BOOK (book_id,  book_name, author,available_copies, total_copies) VALUES ('B4334', 'MOnk Who Sold Ferrari', 'Robbin', 3, 5);
