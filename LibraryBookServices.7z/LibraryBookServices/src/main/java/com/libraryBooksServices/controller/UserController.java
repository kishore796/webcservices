package com.libraryBooksServices.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.libraryBooksServices.model.User;
import com.libraryBooksServices.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService user;
	
	@RequestMapping(value = "/userId", method= RequestMethod.GET, produces = "application/json")
	public Optional<User> getUserById(@RequestParam String id){
		return user.getUserById(id);
		
	}
	
	@RequestMapping(value = "/users", method= RequestMethod.GET, produces = "application/json")
	public List<User> getUsers(){
		return user.getUsers();
	}

}
