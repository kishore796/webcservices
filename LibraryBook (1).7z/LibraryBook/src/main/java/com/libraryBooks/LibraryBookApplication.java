package com.libraryBooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.libraryBooks")
@SpringBootApplication
@EnableEurekaClient
public class LibraryBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryBookApplication.class, args);
	}

}
