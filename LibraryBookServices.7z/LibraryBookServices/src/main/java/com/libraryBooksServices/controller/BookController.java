package com.libraryBooksServices.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.libraryBooksServices.model.Book;
import com.libraryBooksServices.service.BookService;

@RestController
public class BookController {
	
	@Autowired
	private BookService book;
	
	@RequestMapping(value = "/books", method= RequestMethod.GET, produces = "application/json")
	public List<Book> getBooks(){
		return book.getBooks();
	}
	
	@RequestMapping(value = "/books/{bookId}", method= RequestMethod.GET, produces = "application/json")
	public Book getBookByID(@PathVariable String bookId) {
		return book.getBookByID(bookId);
		
	}
	
	@RequestMapping(value = "/books/UpdateAvailability/{bookId}/{availableCopies}", method= RequestMethod.GET, produces = "application/json")
	public Book updateAvailability(@PathVariable String bookId, @PathVariable int availableCopies) {
		return book.updateAvailability(bookId, availableCopies);
	}

}
