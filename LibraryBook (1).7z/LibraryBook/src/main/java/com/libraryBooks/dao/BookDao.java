package com.libraryBooks.dao;

import java.util.*;
import org.springframework.data.repository.CrudRepository;
import com.libraryBooks.model.Book;

public interface BookDao extends CrudRepository<Book, String> {
	
	List<Book> findAll();
	
	Optional<Book> findById(String bookId);


}
