package com.libraryBooksServices.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.libraryBooksServices.model.Subscription;

public interface SubscriptionDao extends CrudRepository<Subscription, String> {

	List<Subscription> findAll();

	Optional<Subscription> findById(String subscriberName);
}
