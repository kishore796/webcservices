package com.libraryBooks.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.libraryBooks.dao.UserDao;
import com.libraryBooks.model.User;

@Service
public class UserService {
	
	@Autowired
	private UserDao user;
	
	public Optional<User> getUserById(String id) {
		return user.findById(id);
		
	}

	public List<User> getUsers() {
		return user.findAll();
	}

}
