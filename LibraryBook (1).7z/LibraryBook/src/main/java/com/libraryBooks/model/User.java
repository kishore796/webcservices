package com.libraryBooks.model;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name = "USER")
public class User implements Serializable{
	
	
	@Id
	@Column(name = "id")
	private String id;
	
	@Column(name = "subscriber_name")
	private String subscriberName;
	
	private String password;
	
	private String email;

	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", subscriberName=" + subscriberName + ", password=" + password + ", email=" + email
				+ "]";
	}
	
	
	
	
	

}
