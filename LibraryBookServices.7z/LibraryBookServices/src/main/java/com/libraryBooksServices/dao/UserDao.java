package com.libraryBooksServices.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.libraryBooksServices.model.User;

public interface UserDao extends CrudRepository<User, String>{
	
	Optional<User> findById(String id);
	
	List<User> findAll();

}
