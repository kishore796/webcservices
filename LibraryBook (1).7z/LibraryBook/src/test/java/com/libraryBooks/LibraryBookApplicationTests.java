package com.libraryBooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
