INSERT INTO USER (id, subscriber_name, password, email) VALUES ('John', 'John Miller', 'abc', 'abc@gmail.com');
INSERT INTO USER (id, subscriber_name, password, email) VALUES ('Mark', 'Mark Waughn','abc', 'xyz@email.com');
INSERT INTO USER (id, subscriber_name, password, email) VALUES ('Peter', 'Peter America','abc', 'cap@marvel.com');
  
INSERT INTO SUBSCRIPTION (subscriber_name,date_subscribed,date_returned, book_id) VALUES ('John', TO_DATE('12-JUN-2020','dd-MON-yyyy'), TO_DATE('14-JUN-2020','dd-MON-yyyy'),  'B1212');
INSERT INTO SUBSCRIPTION (subscriber_name,date_subscribed,date_returned, book_id) VALUES ('Mark', TO_DATE('26-APR-2020','dd-MON-yyyy'), TO_DATE('14-MAY-2020','dd-MON-yyyy'),  'B4334');
INSERT INTO SUBSCRIPTION (subscriber_name,date_subscribed,date_returned, book_id) VALUES ('Peter', TO_DATE('22-JUN-2020','dd-MON-yyyy'), TO_DATE('14-JUL-2020','dd-MON-yyyy'), 'B1212');